#!/bin/bash

# Adres IP serwera Minecraft
IP="BartoszSerwerMinecraft.pl"

# Motyw wiadomości
MOTD="\u00A71W\u00A72I\u00A73T\u00A74A\u00A75M\u00A76Y\u00A71NA\u00A71SERWERZE"

# Tworzenie folderu MinecraftAlwaysOnline, jeśli nie istnieje
mkdir -p MinecraftAlwaysOnline

# Tworzenie folderu plugins_jar, jeśli nie istnieje
mkdir -p plugins_jar

# Pobieranie serwera Spigot wersji 1.19.3
wget https://cdn.getbukkit.org/spigot/spigot-1.19.3.jar -O spigot.jar

# Pobieranie pluginu LuckPerms
wget https://github.com/lucko/LuckPerms/releases/download/5.3/luckperms-plugin-5.3.jar -P plugins_jar/

# Pobieranie pluginu EssentialsX
wget https://ci.ender.zone/job/EssentialsX/lastSuccessfulBuild/artifact/Essentials/target/EssentialsX-2.x-SNAPSHOT.jar -P plugins_jar/

# Uruchamianie serwera Spigot z pluginami
java -Xmx2G -Xms1G -jar spigot.jar nogui